# Tetris

This was a fun project where I recreate Tetris with basic javascript 
(and html/css)

## Run

Run `index.html` on your browser to play

## Controls:
- Left: A, left arrow key
- Right: D, right arrow key
- Speed up (down): S, down arrow key
- Rotate Left: Q, Z
- Rotate Right: E, X, up arrow key
- Drop Piece: space, enter
- Store Piece: W, C, shift

